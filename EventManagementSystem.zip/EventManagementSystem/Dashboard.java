import java.util.*;

public class Dashboard {

    static Scanner scanner = new Scanner(System.in);

    static ArrayList<Event> events = new ArrayList<>();

    static AVLTree avlTree = new AVLTree();

    static Graph graph = new Graph();

    static boolean loaded = false;


    // ========================================
    // SHOW DASHBOARD
    // ========================================

    public static void showDashboard() {

        loadEvents();

        while (true) {

            System.out.println();
            System.out.println("========================================");
            System.out.println("        EVENT MANAGEMENT SYSTEM");
            System.out.println("========================================");
            System.out.println("1. View Events");
            System.out.println("2. Search Events");
            System.out.println("3. Book Event");
            System.out.println("4. Ticket Availability");
            System.out.println("5. Create Schedule");
            System.out.println("6. Event Routes");
            System.out.println("7. My Bookings");
            System.out.println("8. Exit");
            System.out.println("========================================");

            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();

            switch (choice) {

                case "1":
                    viewEvents();
                    break;

                case "2":
                    searchEvents();
                    break;

                case "3":
                    bookEvent();
                    break;

                case "4":
                    ticketAvailability();
                    break;

                case "5":
                    createSchedule();
                    break;

                case "6":
                    eventRoutes();
                    break;

                case "7":
                    Booking.showMyBookings();
                    break;

                case "8":
                    System.out.println();
                    System.out.println("Thank you for using Event Management System!");
                    return;

                default:
                    System.out.println();
                    System.out.println("Invalid choice.");
            }
        }
    }


    // ========================================
    // LOAD EVENTS
    // ========================================

    static void loadEvents() {

        if (loaded) {
            return;
        }

        loaded = true;

        Event e1 = new Event(
                1,
                "Tech Fest",
                "20-09-2026",
                "10:00 AM",
                "Main Block",
                50
        );

        Event e2 = new Event(
                2,
                "Cultural Fest",
                "22-09-2026",
                "11:00 AM",
                "Auditorium",
                100
        );

        Event e3 = new Event(
                3,
                "Sports Meet",
                "25-09-2026",
                "09:00 AM",
                "Sports Ground",
                75
        );

        Event e4 = new Event(
                4,
                "AI Workshop",
                "28-09-2026",
                "02:00 PM",
                "CSE Block",
                40
        );

        events.add(e1);
        events.add(e2);
        events.add(e3);
        events.add(e4);


        // Add events to AVL Tree

        avlTree.insert(e1);
        avlTree.insert(e2);
        avlTree.insert(e3);
        avlTree.insert(e4);


        // ========================================
        // EVENT ROUTES
        // ========================================

        graph.addRoute("Main Gate", "Main Block");
        graph.addRoute("Main Block", "CSE Block");
        graph.addRoute("CSE Block", "Auditorium");
        graph.addRoute("Auditorium", "Sports Ground");
    }


    // ========================================
    // 1. VIEW EVENTS
    // ========================================

    static void viewEvents() {

        System.out.println();
        System.out.println("========================================");
        System.out.println("              ALL EVENTS");
        System.out.println("========================================");

        if (events.isEmpty()) {

            System.out.println("No events available.");
            return;
        }

        for (Event event : events) {
            event.displayEvent();
        }
    }


    // ========================================
    // 2. SEARCH EVENTS
    // ========================================

    static void searchEvents() {

        System.out.println();
        System.out.println("========================================");
        System.out.println("             SEARCH EVENTS");
        System.out.println("========================================");

        System.out.print("Enter event name or keyword: ");

        String input = scanner.nextLine().trim();

        if (input.isEmpty()) {

            System.out.println("Please enter a search term.");
            return;
        }


        LinkedHashSet<Event> matchedEvents =
                new LinkedHashSet<>();


        // AVL TREE - EXACT SEARCH

        Event exactEvent = avlTree.search(input);

        if (exactEvent != null) {
            matchedEvents.add(exactEvent);
        }


        // KMP SEARCH

        for (Event event : events) {

            if (KMP.search(event.getName(), input)) {
                matchedEvents.add(event);
            }
        }


        // RABIN-KARP SEARCH

        for (Event event : events) {

            if (RabinKarp.search(event.getName(), input)) {
                matchedEvents.add(event);
            }
        }


        // Z ALGORITHM SEARCH

        for (Event event : events) {

            if (ZAlgorithm.search(event.getName(), input)) {
                matchedEvents.add(event);
            }
        }


        // FUZZY MATCHING + EDIT DISTANCE

        for (Event event : events) {

            if (FuzzyMatching.isMatch(
                    input,
                    event.getName())) {

                matchedEvents.add(event);
            }
        }


        // DISPLAY RESULTS

        if (matchedEvents.isEmpty()) {

            System.out.println();
            System.out.println("No matching event found.");

            return;
        }


        System.out.println();
        System.out.println("             SEARCH RESULTS");


        for (Event event : matchedEvents) {

            event.displayEvent();
        }
    }


    // ========================================
    // 3. BOOK EVENT
    // ========================================

    static void bookEvent() {

        System.out.println();
        System.out.println("========================================");
        System.out.println("              BOOK EVENT");
        System.out.println("========================================");

        System.out.print("Enter event name: ");

        String name = scanner.nextLine().trim();


        // AVL Tree search
        // This search is NOT case-sensitive

        Event event = avlTree.search(name);


        if (event == null) {

            System.out.println();
            System.out.println("Event not found.");
            return;
        }


        // CHECK IF SOLD OUT

        if (event.getAvailableTickets() == 0) {

            System.out.println();
            System.out.println("Sorry, this event is SOLD OUT.");
            System.out.println("No tickets are available.");

            return;
        }


        System.out.println();
        System.out.println("Event: " + event.getName());

        System.out.println(
                "Available Tickets: "
                + event.getAvailableTickets()
        );


        // ASK NUMBER OF TICKETS

        System.out.print(
                "How many tickets do you want to book? "
        );

        String input = scanner.nextLine().trim();

        int quantity;


        try {

            quantity = Integer.parseInt(input);

        } catch (NumberFormatException e) {

            System.out.println();
            System.out.println("Please enter a valid number.");

            return;
        }


        // VALIDATE QUANTITY

        if (quantity <= 0) {

            System.out.println();
            System.out.println(
                    "Ticket quantity must be greater than 0."
            );

            return;
        }


        // CHECK AVAILABLE TICKETS

        if (quantity > event.getAvailableTickets()) {

            System.out.println();
            System.out.println("Not enough tickets available.");

            System.out.println(
                    "You requested: " + quantity
            );

            System.out.println(
                    "Tickets available: "
                    + event.getAvailableTickets()
            );

            return;
        }


        // BOOK TICKETS

        boolean success =
                Booking.bookEvent(event, quantity);


        if (success) {

            System.out.println();
            System.out.println("========================================");
            System.out.println("          BOOKING SUCCESSFUL");
            System.out.println("========================================");

            System.out.println(
                    "Event            : "
                    + event.getName()
            );

            System.out.println(
                    "Tickets Booked   : "
                    + quantity
            );

            System.out.println(
                    "Tickets Remaining: "
                    + event.getAvailableTickets()
            );

            System.out.println("========================================");

        } else {

            System.out.println();
            System.out.println("Booking failed.");
        }
    }


    // ========================================
    // 4. TICKET AVAILABILITY
    // ========================================

    static void ticketAvailability() {

        System.out.println();
        System.out.println("========================================");
        System.out.println("          TICKET AVAILABILITY");
        System.out.println("========================================");

        System.out.print("Enter event name: ");

        String name = scanner.nextLine().trim();


        Event event = avlTree.search(name);


        if (event == null) {

            System.out.println();
            System.out.println("Event not found.");
            return;
        }


        System.out.println();
        System.out.println("Event Name        : "
                + event.getName());

        System.out.println("Total Tickets     : "
                + event.getTotalTickets());

        System.out.println("Available Tickets : "
                + event.getAvailableTickets());
    }


    // ========================================
    // 5. CREATE SCHEDULE
    // ========================================

    static void createSchedule() {

        System.out.println();
        System.out.println("========================================");
        System.out.println("            EVENT SCHEDULE");
        System.out.println("========================================");


        ArrayList<Event> schedule =
                new ArrayList<>(events);


        // Sorting algorithm

        schedule.sort(
                Comparator.comparing(Event::getTime)
        );


        for (Event event : schedule) {

            System.out.println();
            System.out.println(
                    event.getTime()
                    + " - "
                    + event.getName()
                    + " - "
                    + event.getLocation()
            );
        }
    }


    // ========================================
    // 6. EVENT ROUTES
    // ========================================

    static void eventRoutes() {

        System.out.println();
        System.out.println("========================================");
        System.out.println("             EVENT ROUTES");
        System.out.println("========================================");

        System.out.print("Enter starting location: ");

        String start = scanner.nextLine().trim();

        System.out.print("Enter destination: ");

        String destination = scanner.nextLine().trim();


        // Graph + BFS

        graph.findRoute(start, destination);
    }
}