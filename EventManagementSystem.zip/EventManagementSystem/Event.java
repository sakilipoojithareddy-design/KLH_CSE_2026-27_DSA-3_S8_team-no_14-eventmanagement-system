public class Event {

    private int id;
    private String name;
    private String date;
    private String time;
    private String location;
    private int totalTickets;
    private int availableTickets;

    public Event(int id, String name, String date, String time,
                 String location, int totalTickets) {

        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.location = location;
        this.totalTickets = totalTickets;
        this.availableTickets = totalTickets;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }

    public int getTotalTickets() {
        return totalTickets;
    }

    public int getAvailableTickets() {
        return availableTickets;
    }

    public boolean bookTicket() {

        if (availableTickets > 0) {
            availableTickets--;
            return true;
        }

        return false;
    }

    public void displayEvent() {

        System.out.println("----------------------------------------");
        System.out.println("Event ID          : " + id);
        System.out.println("Event Name        : " + name);
        System.out.println("Date              : " + date);
        System.out.println("Time              : " + time);
        System.out.println("Location          : " + location);
        System.out.println("Total Tickets     : " + totalTickets);
        System.out.println("Available Tickets : " + availableTickets);
        System.out.println("----------------------------------------");
    }
}