public class AVLTree {

    class Node {

        Event event;
        Node left;
        Node right;
        int height;

        Node(Event event) {
            this.event = event;
            this.height = 1;
        }
    }

    private Node root;

    private int height(Node node) {

        if (node == null) {
            return 0;
        }

        return node.height;
    }

    private int getBalance(Node node) {

        if (node == null) {
            return 0;
        }

        return height(node.left) - height(node.right);
    }

    private Node rightRotate(Node y) {

        Node x = y.left;
        Node temp = x.right;

        x.right = y;
        y.left = temp;

        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x;
    }

    private Node leftRotate(Node x) {

        Node y = x.right;
        Node temp = y.left;

        y.left = x;
        x.right = temp;

        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }

    private Node insert(Node node, Event event) {

        if (node == null) {
            return new Node(event);
        }

        if (event.getName().compareToIgnoreCase(node.event.getName()) < 0) {

            node.left = insert(node.left, event);

        } else if (event.getName().compareToIgnoreCase(node.event.getName()) > 0) {

            node.right = insert(node.right, event);

        } else {

            return node;
        }

        node.height =
                Math.max(height(node.left), height(node.right)) + 1;

        int balance = getBalance(node);

        // Left Left
        if (balance > 1 &&
                event.getName().compareToIgnoreCase(
                        node.left.event.getName()) < 0) {

            return rightRotate(node);
        }

        // Right Right
        if (balance < -1 &&
                event.getName().compareToIgnoreCase(
                        node.right.event.getName()) > 0) {

            return leftRotate(node);
        }

        // Left Right
        if (balance > 1 &&
                event.getName().compareToIgnoreCase(
                        node.left.event.getName()) > 0) {

            node.left = leftRotate(node.left);

            return rightRotate(node);
        }

        // Right Left
        if (balance < -1 &&
                event.getName().compareToIgnoreCase(
                        node.right.event.getName()) < 0) {

            node.right = rightRotate(node.right);

            return leftRotate(node);
        }

        return node;
    }

    public void insert(Event event) {

        root = insert(root, event);
    }

    public Event search(String name) {

        Node current = root;

        while (current != null) {

            int comparison =
                    name.compareToIgnoreCase(current.event.getName());

            if (comparison == 0) {

                return current.event;

            } else if (comparison < 0) {

                current = current.left;

            } else {

                current = current.right;
            }
        }

        return null;
    }
}
