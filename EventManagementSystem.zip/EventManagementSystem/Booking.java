import java.util.ArrayList;

public class Booking {

    private static ArrayList<Event> myBookings = new ArrayList<>();


    // ========================================
    // BOOK MULTIPLE TICKETS
    // ========================================

    public static boolean bookEvent(Event event, int quantity) {

        // Check valid event and quantity

        if (event == null || quantity <= 0) {
            return false;
        }


        // Check whether enough tickets are available

        if (event.getAvailableTickets() < quantity) {
            return false;
        }


        // Book the requested number of tickets

        for (int i = 0; i < quantity; i++) {

            event.bookTicket();

            myBookings.add(event);
        }


        return true;
    }


    // ========================================
    // SHOW MY BOOKINGS
    // ========================================

    public static void showMyBookings() {

        System.out.println();
        System.out.println("========================================");
        System.out.println("             MY BOOKINGS");
        System.out.println("========================================");


        // No bookings

        if (myBookings.isEmpty()) {

            System.out.println("No bookings found.");

            return;
        }


        // Store each unique event

        ArrayList<Event> uniqueEvents =
                new ArrayList<>();


        // Store number of tickets booked
        // for each event

        ArrayList<Integer> quantities =
                new ArrayList<>();


        // Count bookings

        for (Event event : myBookings) {

            int index =
                    uniqueEvents.indexOf(event);


            if (index == -1) {

                // First booking for this event

                uniqueEvents.add(event);

                quantities.add(1);

            } else {

                // Event already exists

                quantities.set(
                        index,
                        quantities.get(index) + 1
                );
            }
        }


        // ========================================
        // DISPLAY BOOKINGS
        // ========================================

        for (int i = 0; i < uniqueEvents.size(); i++) {

            Event event =
                    uniqueEvents.get(i);

            System.out.println("----------------------------------------");

            System.out.println(
                    "Event ID       : "
                    + event.getId()
            );

            System.out.println(
                    "Event Name     : "
                    + event.getName()
            );

            System.out.println(
                    "Date           : "
                    + event.getDate()
            );

            System.out.println(
                    "Time           : "
                    + event.getTime()
            );

            System.out.println(
                    "Location       : "
                    + event.getLocation()
            );

            System.out.println(
                    "Tickets Booked : "
                    + quantities.get(i)
            );

            System.out.println("----------------------------------------");
        }
    }
}