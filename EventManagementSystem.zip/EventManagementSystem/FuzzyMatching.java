public class FuzzyMatching {

    public static boolean isMatch(String input, String eventName) {

        if (input == null || eventName == null) {
            return false;
        }

        input = input.toLowerCase().trim();
        eventName = eventName.toLowerCase().trim();

        int distance = EditDistance.calculate(input, eventName);

        int allowedDistance;

        if (eventName.length() <= 5) {
            allowedDistance = 1;
        }
        else if (eventName.length() <= 10) {
            allowedDistance = 2;
        }
        else {
            allowedDistance = 3;
        }

        return distance <= allowedDistance;
    }
}
