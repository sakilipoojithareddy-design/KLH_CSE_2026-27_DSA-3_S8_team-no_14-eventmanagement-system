import java.util.*;

public class Graph {

    private Map<String, List<String>> graph = new HashMap<>();

    // Add a location
    public void addLocation(String location) {
        graph.putIfAbsent(location, new ArrayList<>());
    }

    // Add a route between two locations
    public void addRoute(String location1, String location2) {

        addLocation(location1);
        addLocation(location2);

        graph.get(location1).add(location2);
        graph.get(location2).add(location1);
    }

    // BFS to find route
    public void findRoute(String start, String destination) {

        if (!graph.containsKey(start) || !graph.containsKey(destination)) {

            System.out.println("Location not found.");
            return;
        }

        Queue<String> queue = new LinkedList<>();
        Map<String, String> previous = new HashMap<>();
        Set<String> visited = new HashSet<>();

        queue.add(start);
        visited.add(start);

        while (!queue.isEmpty()) {

            String current = queue.poll();

            if (current.equalsIgnoreCase(destination)) {
                break;
            }

            for (String neighbour : graph.get(current)) {

                if (!visited.contains(neighbour)) {

                    visited.add(neighbour);
                    previous.put(neighbour, current);
                    queue.add(neighbour);
                }
            }
        }

        if (!visited.contains(destination)) {

            System.out.println("No route found.");
            return;
        }

        // Construct route
        List<String> route = new ArrayList<>();

        String current = destination;

        while (current != null) {

            route.add(current);
            current = previous.get(current);
        }

        Collections.reverse(route);

        System.out.println();
        System.out.println("========================================");
        System.out.println("             EVENT ROUTE");
        System.out.println("========================================");

        for (int i = 0; i < route.size(); i++) {

            System.out.print(route.get(i));

            if (i < route.size() - 1) {
                System.out.print(" -> ");
            }
        }

        System.out.println();
        System.out.println("========================================");
    }
}